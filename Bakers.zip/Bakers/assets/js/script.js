$(document).ready(function(){
    $('#slides').superslides({
		animation: 'fade',
		play: 5000,
		pagination: false
    });

    if($(".typed").length != 0){
        var typed = new Typed(".typed", {
            strings: ["Awesome Cakes", "Taste that you'll never forget"],
            typeSpeed: 70,
            loop: true,
            startDelay: 1000,
            showCursor: false
        });
    }

});